package com.fjordtek.chapter0_helloworld;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Chapter0HelloworldApplicationTests {

	@Test
	void contextLoads() {
	}

}
