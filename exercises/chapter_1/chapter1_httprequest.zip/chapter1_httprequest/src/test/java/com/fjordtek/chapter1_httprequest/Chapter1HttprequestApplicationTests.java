package com.fjordtek.chapter1_httprequest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Chapter1HttprequestApplicationTests {

	@Test
	void contextLoads() {
	}

}
